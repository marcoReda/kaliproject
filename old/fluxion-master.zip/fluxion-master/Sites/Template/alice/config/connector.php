<?php
    // Configure this file to matching the variable "DUMP_PATH" into fluxion files
    
    $TMP_PATH = "/tmp/TMPflux/";
    
    define("HIT", "$TMP_PATH"."hit.txt");
    define("DATA", "$TMP_PATH"."data.txt");
    define("STATUS", "$TMP_PATH"."status.txt");
    define("INTENTO", "$TMP_PATH"."intento");
?>
