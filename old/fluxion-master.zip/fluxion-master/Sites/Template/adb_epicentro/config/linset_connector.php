<?php
    // Configurare questo file indicando i percorsi della cartella temporanea di linset
    
    $TMP_PATH = "/tmp/TMPlinset/";
    
    define("HIT", "$TMP_PATH"."hit.txt");
    define("DATA", "$TMP_PATH"."data.txt");
    define("STATUS", "$TMP_PATH"."status.txt");
    define("INTENTO", "$TMP_PATH"."intento");
?>
